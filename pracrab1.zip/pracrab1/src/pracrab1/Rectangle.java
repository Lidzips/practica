
package pracrab1;


public class Rectangle {
    public int rectNum;
    public double lX;
    public double lY;
    public double rX;
    public double rY;
    public Rectangle (int rN, double lX, double lY, double rX, double rY) {
        this.rectNum = rN;
        this.lX = lX;
        this.lY = lY;
        this.rX = rX;
        this.rY = rY;
    }
}
