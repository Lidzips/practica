
package pracrab2;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Pracrab2 {
    
    public static File[] getFileArray(String path){
    File f = new File(path);
    File[] list = f.listFiles();
    return list;
    }

    public static void main(String[] args) {
        File[] f = getFileArray("in");
        System.out.println(f[0].getName());
        File file = new File(f[0].getAbsolutePath());
        ObjectMapper mapper = new ObjectMapper();
        DataObject dataObject = new DataObject();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);            
        try {
            dataObject = mapper.readValue(file, DataObject.class);
        } catch (IOException ex) {
            Logger.getLogger(Pracrab2.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String jsonObject = new String();
        try {
            jsonObject = mapper.writeValueAsString(dataObject);
        } catch (JsonProcessingException ex) {
            Logger.getLogger(Pracrab2.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(jsonObject);
        String trans = transliterate1(jsonObject);
        System.out.println(trans);
        System.out.println(dataObject.getLname());

        trans = fiod(trans);
        System.out.println(trans);
        
        try {
            String html = "<!doctype html>\n<html dir=\"ltr\" lang=\"ru\"><head><meta charset=\"utf-8\">"+
                    "<title>Добро пожаловать в Chrome!</title></head><body>"+trans+"</body></html>";
            File[] f1 = getFileArray("out");
            System.out.println(f1[0].getName());
            File file1 = new File(f1[0].getAbsolutePath());
            FileOutputStream fos = new FileOutputStream(file1);
            fos.write(html.getBytes("utf-8"));
            fos.flush();
            fos.close();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }    
 
    }
     
    public static String transliterate1(String message){
        char[] abcCyr1 = {'а','б','в','г','д','е','ё', 'ж','з','и','й','к','л','м','н','о','п','р','с','т','у','ф','х', 'ц','ч', 'ш','щ','ъ','ы','ь','э', 'ю','я','А','Б','В','Г','Д','Е','Ё', 'Ж','З','И','Й','К','Л','М','Н','О','П','Р','С','Т','У','Ф','Х', 'Ц', 'Ч','Ш', 'Щ','Ъ','Ы','Ь','Э','Ю','Я'};
        char[] abcCyr = {' ',',',':','.','а','б','в','г','д','е','ё','ж','з','и','й','к','л','м','н','о','п','р','с','т','у','ф','х','ц','ч','ш','щ','ъ','ы','ь','э', 'ю','я','А','Б','В','Г','Д','Е','Ё', 'Ж','З','И','Й','К','Л','М','Н','О','П','Р','С','Т','У','Ф','Х', 'Ц', 'Ч','Ш', 'Щ','Ъ','Ы','Ь','Э','Ю','Я','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','1','2','3','4','5','6','7','8','9','0'};
        String[] abcLat = {" ",", "," ",".","a","b","v","g","d","e","e","zh","z","i","y","k","l","m","n","o","p","r","s","t","u","f","h","ts","ch","sh","sch", "","i", "","e","ju","ja","A","B","V","G","D","E","E","Zh","Z","I","Y","K","L","M","N","O","P","R","S","T","U","F","H","Ts","Ch","Sh","Sch", "","I", "","E","Ju","Ja","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","1","2","3","4","5","6","7","8","9","0"};
        StringBuilder builder = new StringBuilder(message);
        StringBuilder builder1 = new StringBuilder();
        int k = 1;
        for (int i = 0; i < message.length(); i++) {
            for (int x = 0; x < abcCyr1.length; x++ ) {
                
                if (message.charAt(i) == abcCyr1[x] && message.charAt(i+1) == '"') {
                    builder.insert(i+k, " / ");
                    k += 3;
                }
                
            } 
        }
        message = builder.toString();
        for (int i = 1; i < message.length(); i++) {
            for (int x = 0; x < abcCyr1.length; x++ ) {
                if (message.charAt(i) == abcCyr[x]) {
                    builder1.append(abcLat[x]);
                }
                if (message.charAt(i-1) == abcCyr1[x] && message.charAt(i+1) == '/') {
                    builder.insert(i+3, builder1);
                    message = builder.toString();
                }
                if (message.charAt(i) == ':') {
                    builder1.delete(0, i);
                }
            } 
        }
        for (int i = 0; i < message.length(); i++) {
            if (message.charAt(i) == '"' || message.charAt(i) == '{' || message.charAt(i) == '}') {
                builder.deleteCharAt(i);
                message = builder.toString();
                i = i -1;
            }
        }
        return builder.toString();
    }
    
    public static String fiod(String message){
        message = message.replace("lname", "Фамилия");
        message = message.replace("fname", "Имя");
        message = message.replace("mname", "Отчество");
        message = message.replace("bdate", "Дата Рождения");
        return message; 
    }
    
}
   