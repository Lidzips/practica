
package pracrab2;

class DataObject {
    private String lname;
    private String fname;
    private String mname;
    private String bdate;
    
    public String getLname() {
        return lname;
    }
    
    public void setLname(String lname) {
        this.lname = lname;
    }
    
    public String getFname() {
        return fname;
    }
    
    public void setFname(String fname) {
        this.fname = fname;
    }
    
    public String getMname() {
        return mname;
    }
    
    public void setMname(String mname) {
        this.mname = mname;
    }
    public String getBdate() {
        return bdate;
    }
    
    public void setBdate(String bdate) {
        this.bdate = bdate;
    }
    
    @Override
    public String toString() {
        return "Person{" +
                "lname='" + lname + '\'' +
                ", fname='" + fname + '\'' +
                ", mname='" + mname + '\'' +
                ", bdate='" + bdate +
                '}';
    }
}

